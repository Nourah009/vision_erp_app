// services/notification_service.dart
import 'dart:convert';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vision_erp_app/screens/models/notification_model.dart';

class NotificationService {
  static const String _notificationsKey = 'user_notifications';

  static Future<List<NotificationModel>> getNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notificationsJson = prefs.getString(_notificationsKey);
      
      if (notificationsJson == null) {
        return _getDefaultNotifications();
      }
      
      final List<dynamic> notificationsList = json.decode(notificationsJson);
      return notificationsList.map((item) => NotificationModel(
        id: item['id'],
        title: item['title'],
        message: item['message'],
        timestamp: DateTime.parse(item['timestamp']),
        isRead: item['isRead'],
        type: NotificationType.values[item['type']],
        relatedId: item['relatedId'],
      )).toList();
    } catch (e) {
      print('Error getting notifications: $e');
      return _getDefaultNotifications();
    }
  }

  static Future<void> saveNotifications(List<NotificationModel> notifications) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notificationsJson = json.encode(notifications.map((notification) => {
        'id': notification.id,
        'title': notification.title,
        'message': notification.message,
        'timestamp': notification.timestamp.toIso8601String(),
        'isRead': notification.isRead,
        'type': notification.type.index,
        'relatedId': notification.relatedId,
      }).toList());
      
      await prefs.setString(_notificationsKey, notificationsJson);
    } catch (e) {
      print('Error saving notifications: $e');
    }
  }

  static Future<void> addNotification(NotificationModel notification) async {
    final notifications = await getNotifications();
    notifications.insert(0, notification);
    await saveNotifications(notifications);
  }

  static Future<void> markAsRead(String notificationId) async {
    final notifications = await getNotifications();
    final index = notifications.indexWhere((n) => n.id == notificationId);
    
    if (index != -1) {
      notifications[index] = notifications[index].copyWith(isRead: true);
      await saveNotifications(notifications);
    }
  }

  static Future<void> markAllAsRead() async {
    final notifications = await getNotifications();
    final updatedNotifications = notifications.map((notification) 
      => notification.copyWith(isRead: true)).toList();
    await saveNotifications(updatedNotifications);
  }

  static Future<void> deleteNotification(String notificationId) async {
    final notifications = await getNotifications();
    notifications.removeWhere((n) => n.id == notificationId);
    await saveNotifications(notifications);
  }

  static Future<int> getUnreadCount() async {
    final notifications = await getNotifications();
    return notifications.where((n) => !n.isRead).length;
  }

  static Future<void> clearAllNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_notificationsKey);
  }

  // إشعارات افتراضية خاصة بالتطبيق بالإنجليزية
  static List<NotificationModel> _getDefaultNotifications() {
    return [
      NotificationModel(
        id: '1',
        title: 'Welcome to Vision ERP',
        message: 'Your account has been successfully setup. Explore all features now.',
        timestamp: DateTime.now().subtract(const Duration(hours: 2)),
        type: NotificationType.general,
      ),
      NotificationModel(
        id: '2',
        title: 'Weekly Sales Report Ready',
        message: 'Last week sales report is ready for review. Check your performance metrics.',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        type: NotificationType.salesReport,
        relatedId: 'weekly_sales_1',
      ),
      NotificationModel(
        id: '3',
        title: 'System Update Available',
        message: 'New system version 2.1.0 is available with enhanced features.',
        timestamp: DateTime.now().subtract(const Duration(days: 2)),
        type: NotificationType.systemAlert,
      ),
      NotificationModel(
        id: '4',
        title: 'New Feature: Advanced Analytics',
        message: 'Check out the new advanced analytics dashboard for better insights.',
        timestamp: DateTime.now().subtract(const Duration(days: 3)),
        type: NotificationType.newFeature,
      ),
      NotificationModel(
        id: '5',
        title: 'Scheduled Maintenance',
        message: 'System maintenance scheduled for Saturday 10:00 PM - 2:00 AM.',
        timestamp: DateTime.now().subtract(const Duration(days: 4)),
        type: NotificationType.maintenance,
      ),
    ];
  }
 static final List<Map<String, dynamic>> _autoNotifications = [
    {
      'title': 'New Sales Data Available',
      'message': 'Fresh sales data has been synchronized. Check your dashboard for updates.',
      'type': NotificationType.salesReport,
    },
    {
      'title': 'System Performance',
      'message': 'System running optimally. All services are operational.',
      'type': NotificationType.systemAlert,
    },
    {
      'title': 'Daily Summary Ready',
      'message': 'Your daily business summary is ready for review.',
      'type': NotificationType.general,
    },
    {
      'title': 'Inventory Update',
      'message': 'Inventory levels have been updated with latest stock counts.',
      'type': NotificationType.systemAlert,
    },
    {
      'title': 'User Activity Report',
      'message': 'Weekly user activity report generated successfully.',
      'type': NotificationType.userActivity,
    },
    {
      'title': 'Data Backup Completed',
      'message': 'Automatic data backup completed successfully.',
      'type': NotificationType.security,
    },
    {
      'title': 'New Features Available',
      'message': 'Check out the latest features added to Vision ERP system.',
      'type': NotificationType.newFeature,
    },
    {
      'title': 'Performance Tips',
      'message': 'Tip: Use keyboard shortcuts to navigate faster in the system.',
      'type': NotificationType.reminder,
    },
  ];

  // إنشاء إشعار عشوائي تلقائي
  static Future<void> generateAutoNotification() async {
    final random = Random();
    final notificationData = _autoNotifications[random.nextInt(_autoNotifications.length)];
    
    final notification = NotificationModel(
      id: 'auto_${DateTime.now().millisecondsSinceEpoch}',
      title: notificationData['title'] as String,
      message: notificationData['message'] as String,
      timestamp: DateTime.now(),
      type: notificationData['type'] as NotificationType,
    );

    await addNotification(notification);
    print('Auto notification generated: ${notification.title}');
  }

  // إنشاء إشعارات خاصة بالمبيعات
  static Future<void> generateSalesNotification() async {
    final salesMessages = [
      'New sales order #${Random().nextInt(1000) + 1000} has been created.',
      'Monthly sales target achieved: ${Random().nextInt(30) + 70}% completed.',
      'Customer payment received for invoice #INV-${DateTime.now().month}${Random().nextInt(100)}.',
      'Sales team performance: ${Random().nextInt(40) + 60}% of weekly goal reached.',
      'New customer registered in the system. Welcome to Vision ERP!',
    ];

    final notification = NotificationModel(
      id: 'sales_${DateTime.now().millisecondsSinceEpoch}',
      title: 'Sales Update',
      message: salesMessages[Random().nextInt(salesMessages.length)],
      timestamp: DateTime.now(),
      type: NotificationType.salesReport,
    );

    await addNotification(notification);
  }

  // إنشاء إشعارات تنبيه النظام
  static Future<void> generateSystemNotification() async {
    final systemMessages = [
      'System maintenance completed successfully.',
      'New update available for Vision ERP mobile app.',
      'Database optimization completed. Performance improved.',
      'Security scan completed. No threats detected.',
      'Cloud sync completed. All data synchronized.',
    ];

    final notification = NotificationModel(
      id: 'system_${DateTime.now().millisecondsSinceEpoch}',
      title: 'System Alert',
      message: systemMessages[Random().nextInt(systemMessages.length)],
      timestamp: DateTime.now(),
      type: NotificationType.systemAlert,
    );

    await addNotification(notification);
  }
  // إنشاء إشعارات تجريبية خاصة بالتطبيق
  static Future<void> generateSampleAppNotifications() async {
    final sampleNotifications = [
      NotificationModel(
        id: 'app_${DateTime.now().millisecondsSinceEpoch}',
        title: 'Monthly Performance Report',
        message: 'Your monthly performance report shows 25% growth in sales. Great job!',
        timestamp: DateTime.now(),
        type: NotificationType.salesReport,
      ),
      NotificationModel(
        id: 'app_${DateTime.now().millisecondsSinceEpoch + 1}',
        title: 'New Dashboard Features',
        message: 'Enhanced dashboard with real-time analytics and custom widgets available.',
        timestamp: DateTime.now().subtract(const Duration(hours: 3)),
        type: NotificationType.newFeature,
      ),
      NotificationModel(
        id: 'app_${DateTime.now().millisecondsSinceEpoch + 2}',
        title: 'Security Update',
        message: 'Important security update installed. Your data is now more secure.',
        timestamp: DateTime.now().subtract(const Duration(hours: 6)),
        type: NotificationType.security,
      ),
      NotificationModel(
        id: 'app_${DateTime.now().millisecondsSinceEpoch + 3}',
        title: 'Inventory Alert',
        message: 'Low stock alert for 5 products. Please review inventory levels.',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        type: NotificationType.systemAlert,
      ),
      NotificationModel(
        id: 'app_${DateTime.now().millisecondsSinceEpoch + 4}',
        title: 'Backup Completed',
        message: 'Automatic system backup completed successfully at 2:00 AM.',
        timestamp: DateTime.now().subtract(const Duration(days: 2)),
        type: NotificationType.general,
      ),
    ];

    for (final notification in sampleNotifications) {
      await addNotification(notification);
    }
  }
}